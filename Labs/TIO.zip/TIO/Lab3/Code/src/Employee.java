public class Employee {
	// Share the class with the trainees without the following code
	//**************************************************************
	
	// This code is for the trainer's reference
	//***************************************************************
	
//	private String empId;
//	private String name;
//	private Address address;
//	
//	public String getEmpId() {
//		return empId;
//	}
//	public void setEmpId(String empId) {
//		this.empId = empId;
//	}
//	public String getName() {
//		return name;
//	}
//	public void setName(String name) {
//		this.name = name;
//	}
//	public Address getAddress() {
//		return address;
//	}
//	public void setAddress(Address address) {
//		this.address = address;
//	}
}
