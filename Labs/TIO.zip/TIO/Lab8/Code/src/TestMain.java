public class TestMain {
	public static void main(String[] args) {
		if(args.length == 0) {
			System.out.println("Pass a double val!");
			System.exit(0);
		}
		
		double num = 0;
		int whole = 0;
		double fraction = 0;
		
//		For Trainer's reference
//		**************************************************
//		num = Double.parseDouble(args[0]);
		
//		For the Trainees
//		store the value into num by reading it as a command line argument
		
// 		For Trainer's reference
//		**************************************************
//		int whole = DecimalSplitter.getWhole(num);

//		For the Trainee, please give this comment line
//		whole = call the getWhole() method by passing num
		
// 		For Trainer's reference
//		**************************************************
//		fraction = DecimalSplitter.getFraction(num);

//		For the Trainee, please give this comment line
//		fraction = call the getFraction() method by passing num

		System.out.println("Whole : " + whole);
		System.out.printf("Fraction : %.3f\n" , fraction);

		// Explain how this works to the trainees....
		System.out.println("The number is " + (DecimalSplitter.isOdd(whole) ? "Odd" : "Even"));
	}
}
