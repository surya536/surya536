public class Cache {
	private static int MAX_CAPACITY = 0;
	
	// This commented code is for the trainer's reference
	// Do not share with the trainees 
	//***************************************************************

//	static {
//		System.out.println("MAX CAPACITY : ");
//		MAX_CAPACITY = Console.readInt();
//	}

	static int getMaxCapacity() {
		System.out.println("Returning MAX_CAPACITY");
		return MAX_CAPACITY;
	}
}