public class TestMain {
	public static void main(String[] args) {
		System.out.println("MAX_CAPACITY is " + Cache.getMaxCapacity());
		//..
		
		System.out.println("MAX_CAPACITY is " + Cache.getMaxCapacity());

		//...
		System.out.println("MAX_CAPACITY is " + Cache.getMaxCapacity());
	}
}
