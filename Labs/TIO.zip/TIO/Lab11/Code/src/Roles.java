public interface Roles {
//	int DEVELOPER = 1;
//	int TEST_ENGINEER = 2;
//	int SR_DEVELOPER = 3;
//	int DESIGNER = 4;
}