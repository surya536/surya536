public class Roles {
	public static final int DEVELOPER = 1;
	public static final int TEST_ENGINEER = 2;
	public static final int SR_DEVELOPER = 3;
	public static final int DESIGNER = 4;
}