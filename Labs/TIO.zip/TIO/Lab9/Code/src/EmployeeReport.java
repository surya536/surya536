public class EmployeeReport {
	private String dtReport;
	
	private void printLine() {
		System.out.println("---------------------------------------------------------------------------");
	}
	private void displayHeader() {
		printLine();
		System.out.print("EMPLOYEE REPORT\t\t\t\t");
		System.out.println("Date : " + dtReport);
		printLine();
	}
	private void displayFooter(int count) {
		printLine();
		System.out.println("Total Employees : " + count);
		printLine();
	}
	public void display(Employee empArr[]) {
		displayHeader();
		
		System.out.println("EMP_ID\tNAME\tROLE\t\tBASIC\tHRA\tALLOW\tSALARY");
		printLine();
//		for(int i=0;i<empArr.length;++i) {
//			Employee emp = empArr[i];
//			String roleDesc = RoleBuilder.getRoleDescription(emp.getRole());
//			double allowances = SalaryCalculator.getAllowance(emp);
//			double salary = SalaryCalculator.getSalary(emp);
//			
//			System.out.println(emp.getEmpId() + "\t" + emp.getName() + "\t" + roleDesc + "\t" + emp.getBasic() + "\t" + 
//					emp.getHra() + "\t" + allowances + "\t" + salary);
//		}
		
//		displayFooter(empArr.length);
		
		// To Do By The Trainees - display the Footer
	}
	public void setDtReport(String dtReport) {
		this.dtReport = dtReport;
	}
	public String getDtReport() {
		return dtReport;
	}
}